<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/footer.css">
    <title>Footer</title>
</head>
<body>
<div class="webending">
    <div>
        <dl class="gtkdl">Get to Know Us</dl>
        <dt class="gtklist">Blog</dt>
        <dt class="gtklist">About Career</dt>
        <dt class="gtklist">Contact Us</dt>
        <dt class="gtklist"></dt>
        </div>
    <div>
    <dl class="gtkdl">Make Money With Us</dl>
        <dt class="gtklist">Add Ads</dt>
        <dt class="gtklist">Add Your Place</dt>
        <dt class="gtklist"></dt>
        <dt class="gtklist"></dt>
        </div>
        <div>
    <dl class="gtkdl">Let Us Help You</dl>
        <dt class="gtklist">Your Account</dt>
        <dt class="gtklist">Page Assistant</dt>
        <dt class="gtklist"></dt>
        <dt class="gtklist"></dt>
        </div>
</div>
<div class="privacy">
    <p class="term">TERMS OF USE</p>
    <p class="term">PRIVACY POLICY</p>
    <p class="term">COPY RIGHT 2023</p>
</div>
</body>
</html>