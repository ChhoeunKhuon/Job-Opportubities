<?php 
 include ('dbCon.php');
 $qw = 'SELECT * FROM tbldep';
 $rtt =   $dbCon->query($qw);
?>