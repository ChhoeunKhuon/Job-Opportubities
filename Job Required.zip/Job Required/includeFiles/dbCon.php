<?php
  $dbCon = mysqli_connect('localhost', 'root', '', 'dbcareer') or die ('Not Connected');
?>