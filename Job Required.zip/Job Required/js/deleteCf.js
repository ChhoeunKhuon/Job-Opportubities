function deleteCf(){
    confirm('Are you sure want to delete?');
}